#!/bin/bash
hostnamectl set-hostname hq-srv.au-team.irpo

apt update && apt install -y openssh-server dnsmasq

cat > /etc/network/interfaces <<EOF
auto ens3
iface ens3 inet static
 address 192.168.100.2/27
 gateway 192.168.100.1
EOF

echo "nameserver 127.0.0.1" > /etc/resolv.conf

sed -i 's/#Port 22/Port 2026/' /etc/ssh/sshd_config
echo "AllowUsers sshuser" >> /etc/ssh/sshd_config
echo "MaxAuthTries 2" >> /etc/ssh/sshd_config
echo "Banner /etc/ssh_banner" >> /etc/ssh/sshd_config

echo "Authorized access only" > /etc/ssh_banner

useradd -m sshuser
echo "sshuser:P@ssw0rd" | chpasswd
usermod -aG sudo sshuser
echo "sshuser ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

systemctl restart ssh
systemctl restart networking
