#!/bin/bash
hostnamectl set-hostname isp.au-team.irpo

sed -i 's/^deb cdrom/# deb cdrom/' /etc/apt/sources.list
echo "nameserver 8.8.8.8" > /etc/resolv.conf

apt update && apt install -y nftables

cat > /etc/network/interfaces <<EOF
auto lo
iface lo inet loopback

auto ens3
iface ens3 inet dhcp

auto ens4
iface ens4 inet static
 address 172.16.1.1/28

auto ens5
iface ens5 inet static
 address 172.16.2.1/28
EOF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/sysctl.conf
sysctl -p

cat > /etc/nftables.conf <<EOF
flush ruleset
table ip nat {
 chain postrouting {
  type nat hook postrouting priority 100;
  oifname "ens3" masquerade
 }
}
EOF

systemctl enable nftables
systemctl restart nftables
systemctl restart networking
