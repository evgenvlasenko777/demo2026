#!/bin/bash
hostnamectl set-hostname br-rtr.au-team.irpo

apt update && apt install -y nftables

cat > /etc/network/interfaces <<EOF
auto lo
iface lo inet loopback

auto ens3
iface ens3 inet static
 address 172.16.2.2/28
 gateway 172.16.2.1

auto ens4
iface ens4 inet static
 address 192.168.200.1/28
EOF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/sysctl.conf
sysctl -p

useradd -m net_admin
echo "net_admin:P@ssw0rd" | chpasswd
usermod -aG sudo net_admin
echo "net_admin ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

systemctl restart networking
