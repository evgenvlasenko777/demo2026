#!/bin/bash
hostnamectl set-hostname hq-cli.au-team.irpo

cat > /etc/network/interfaces <<EOF
auto ens3
iface ens3 inet dhcp
EOF

systemctl restart networking
