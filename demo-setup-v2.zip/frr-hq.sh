#!/bin/bash

apt install -y frr

sed -i 's/ospfd=no/ospfd=yes/' /etc/frr/daemons
systemctl restart frr

vtysh <<EOF
conf t
router ospf
 router-id 1.1.1.1
 network 192.168.100.0/24 area 0
 network 10.10.0.0/30 area 0
exit
write
EOF
