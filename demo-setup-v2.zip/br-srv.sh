#!/bin/bash

hostnamectl set-hostname br-srv.au-team.irpo

apt update
apt install -y openssh-server

nano /etc/network/interfaces <<EOF
auto ens3
iface ens3 inet static
 address 192.168.200.2/28
 gateway 192.168.200.1
EOF

useradd -m sshuser
echo "sshuser:P@ssw0rd" | chpasswd
usermod -aG sudo sshuser
echo "sshuser ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

systemctl restart ssh
systemctl restart networking
