#!/bin/bash

hostnamectl set-hostname hq-rtr.au-team.irpo

apt update
apt install -y nftables vlan isc-dhcp-server

nano /etc/network/interfaces <<EOF
auto lo
iface lo inet loopback

auto ens3
iface ens3 inet static
 address 172.16.1.2/28
 gateway 172.16.1.1

auto ens3.100
iface ens3.100 inet static
 address 192.168.100.1/27

auto ens3.200
iface ens3.200 inet static
 address 192.168.100.33/28

auto ens3.999
iface ens3.999 inet static
 address 192.168.100.49/29
EOF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/sysctl.conf
sysctl -p

# DHCP
sed -i 's/INTERFACESv4=""/INTERFACESv4="ens3.200"/' /etc/default/isc-dhcp-server

echo "subnet 192.168.100.32 netmask 255.255.255.240 {" >> /etc/dhcp/dhcpd.conf
echo " range 192.168.100.34 192.168.100.47;" >> /etc/dhcp/dhcpd.conf
echo " option routers 192.168.100.33;" >> /etc/dhcp/dhcpd.conf
echo " option domain-name-servers 192.168.100.2;" >> /etc/dhcp/dhcpd.conf
echo " option domain-name "au-team.irpo";" >> /etc/dhcp/dhcpd.conf
echo "}" >> /etc/dhcp/dhcpd.conf

systemctl restart isc-dhcp-server

useradd -m net_admin
echo "net_admin:P@ssw0rd" | chpasswd
usermod -aG sudo net_admin
echo "net_admin ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

systemctl restart networking
