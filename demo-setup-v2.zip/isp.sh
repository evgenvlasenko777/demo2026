#!/bin/bash

hostnamectl set-hostname isp.au-team.irpo

# отключаем cdrom
sed -i 's/^deb cdrom/# deb cdrom/' /etc/apt/sources.list

echo "nameserver 8.8.8.8" > /etc/resolv.conf

apt update
apt install -y nftables

# сеть (редактирование как вручную)
nano /etc/network/interfaces <<EOF
auto lo
iface lo inet loopback

auto ens3
iface ens3 inet dhcp

auto ens4
iface ens4 inet static
 address 172.16.1.1/28

auto ens5
iface ens5 inet static
 address 172.16.2.1/28
EOF

# ip forward
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/sysctl.conf
sysctl -p

# nftables (построчно)
echo "flush ruleset" > /etc/nftables.conf
echo "table ip nat {" >> /etc/nftables.conf
echo " chain postrouting {" >> /etc/nftables.conf
echo "  type nat hook postrouting priority 100; policy accept;" >> /etc/nftables.conf
echo "  meta l4proto { gre, ipip, ospf } counter return" >> /etc/nftables.conf
echo "  masquerade" >> /etc/nftables.conf
echo " }" >> /etc/nftables.conf
echo "}" >> /etc/nftables.conf

echo "table inet filter {" >> /etc/nftables.conf
echo " chain input {" >> /etc/nftables.conf
echo "  type filter hook input priority filter;" >> /etc/nftables.conf
echo " }" >> /etc/nftables.conf
echo " chain forward {" >> /etc/nftables.conf
echo "  type filter hook forward priority filter;" >> /etc/nftables.conf
echo " }" >> /etc/nftables.conf
echo " chain output {" >> /etc/nftables.conf
echo "  type filter hook output priority filter;" >> /etc/nftables.conf
echo " }" >> /etc/nftables.conf
echo "}" >> /etc/nftables.conf

systemctl restart nftables
systemctl restart networking
